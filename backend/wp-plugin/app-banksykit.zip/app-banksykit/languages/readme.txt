Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:
* app_banksykit-de_DE.po
* app_banksykit-id_ID.po
* app_banksykit_ES.po
* app_banksykit-en_US.po
* app_banksykit-de_DE.mo
* app_banksykit-id_ID.mo
* app_banksykit-es_ES.mo
* app_banksykit-en_US.mo
Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
